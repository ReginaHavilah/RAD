package Projet;

public abstract class Graph<E> {
	// considérons dans notre cas que E et T désigne respectivement le type des noeuds et des arcs du graphes 
	// on utilise la généricité ici car on a pas encore connaissance du type de ces éléments 
	
	
public abstract boolean areConnected(E noeud1, E noeud2);// on vérifie si les noeuds 1 et 2 sont reliés 
//en d'autres termes on essai de vérifier s'il existe un arc entre ces deux noeuds
// on retournera vrai ou faux suite à la vérification donc un booléen 
public abstract int getDegree(E noeud); // on recherche le nombre d'arc relié au noeud en paramètre 
// ce qui nous retournera un numérique positif 
public abstract Edge getLightest(); // Ne prend rien en paramètre mais retourne l'arc donc le poid est le plus faible 
public abstract int getWeight(E noeud1, E noeud2); // prend en paramètre un arc et retourne son poids qui est un numérique positif
public abstract int numEdge(); // il renvoi le nombre d'arc dans le graphe 
public abstract void graph(); // génère un nouveau graphe 
public abstract void addEdge(E noeud1, E noeud2, int poids); // ajoute un noeud entre les noeuds 1 et noeud 2 en précisant son poids 
public abstract void addNode(E noeud);// ajoute le noeud en paramètre dans le graphe 
public abstract void  delNode(E noeud); // supprime le noeud en paramètre
public abstract void delEdge(E noeud1, E noeud2);// supprime l'arc en paramètre 

// Notons que les arcs et les noeuds ont un lien étroitement liés 
// les noeuds représente des villes et les arcs les voies ferrés existant entre les noeuds 


}
