package Projet;

public class Edge {
//Cette classe est pour instancier des objets arcs 
  private char sommet1,sommet2;// les deux noeuds relié par l'arc 
  private int poids;// le poids de l'arc 
  public Edge(char sommet1,char sommet2,int poids) {// le constructeur 
	  this.poids=poids;
	  this.sommet1=sommet1;
	  this.sommet2=sommet2;
  }
 // les méthodes getters et setters pour récuperer ou modifier les paramètres 
public char getSommet1() {
	return sommet1;
}
public void setSommet1(char sommet1) {
	this.sommet1 = sommet1;
}
public char getSommet2() {
	return sommet2;
}
public void setSommet2(char sommet2) {
	this.sommet2 = sommet2;
}
public int getPoids() {
	return poids;
}
public void setPoids(int poids) {
	this.poids = poids;
}
// une méthode pour afficher l'arc et ses attributs s
public String toString() {
	return "L'arc en question est de: somment 1:"+sommet1+" et de sommet 2:"+sommet2+" avec un poids="+poids;
}
/*Question: 7 
 * La structure efficace pour stocker les arcs serait un HashMap et on prendra comme clé 
 * le poids de l'arc 
 * L'arc a plusieurs valeurs sommet1,sommet2,et le poids mais celui auquelle on fais le plus appel est le poids 
 * donc il est préfèrable de l'utiliser
 * */ 
}
