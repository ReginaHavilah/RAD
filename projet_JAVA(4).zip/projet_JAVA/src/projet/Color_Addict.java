package projet;


import java.util.ArrayList;

import java.util.Arrays;
import java.util.List;

import projet.Jeu.Niveau;

public class Color_Addict {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  //  Representation inter=new Representation();//représentation graphique 
  Joueur one= new Joueur("Marie-Josée");
  Donneur ouf=new Donneur("Hosni");
  Joueur two= new Joueur("Josiane");
  List<Joueur> liste=new ArrayList<>(Arrays.asList(one,ouf,two));
  Table_jeu table=new Table_jeu();
  Jeu game=new Jeu(liste,table, Niveau.Debutants);
  game.affichage();
  /*
  game.melange();
  game.distribution();
  System.out.println("Les cartes de chaque joueur se présente comme suit:");
 for( Joueur j:liste) {
	  j.affichageMainJoueur();
  }
 */
  String gagnant="";
  gagnant=game.jouer();
  System.out.println("Le gagnant de cette partie est: "+gagnant);
  
	}
}
