package Projet;

import java.util.ArrayList;

public class GraphMatrix extends Graph<Character>{
	//les noeuds représentant des noms de Villes sont des Character qu'on pourra indexer grace à leur index dans la liste de noeud 
	// les arcs sont représenté par leur poids donc ils sont de type entier 
// cette class n'a que deux attributs qui sont les suivants; 
	ArrayList <Character> nodes; // une liste de char contenant le nom des noeuds 
	int [][] edges; // une matrice => tableau a double entrée 
	//Constructeur pour initialiser un graphe sur lequel on peut faire différentes opérations 
	public GraphMatrix() {
		this.nodes=new ArrayList<Character>();
		this.edges= new int[0][0];
	}
	// Cette classe héritant de la classe abstraite Graph doit implementer toutes ces méthodes 
	
	@Override
	//méthode utilisé pour vérifier la connexion entre deux noeuds 
	public boolean areConnected(Character noeud1, Character noeud2) {
		boolean connecté=false; // initialisation de la variable à faux 
	//on vérifie si les deux noeuds en paramètre sont reliés 
	// si dans edge la case corespondant à la relation entre ces deux noeuds 
	//est non nulle alors ils sont connectés, dans le cas contraire ils ne le sont pas 
		
if((edges[nodes.indexOf(noeud1)][nodes.indexOf(noeud2)]==0) ||(edges[nodes.indexOf(noeud2)][nodes.indexOf(noeud1)]==0) ) {
			connecté=false;
		} else connecté=true;
		return connecté;
	}
	@Override
	//retourne le nombre d'arc connecté au noeuds en paramètre 
	public int getDegree(Character noeud) {
		int nbarc=0;
		ArrayList<Character> noeudRelié=new ArrayList<Character>();//une liste des noeuds reliés a ce noeud 
	// On se place dans une boucle pour parcourir toutes les options de liaison du noeud 
	// a un autre noeud du graphe 
		for(int i=0;i<nodes.size();i++) {
		// on vérifie si le noeud en paramètre est relié au noeud à l'indice i (parcours de toute la liste de noeuds) 
			if(edges[i][nodes.indexOf(noeud)]!=0) {
				nbarc++; // le nombre d'arc s'incrémente tant qu'il y a liaison entre ce noeud et un autre 
		noeudRelié.add(nodes.get(i));// s'il y a un arc entre ce noeud et un autre on met cet autre noeud dans la liste des neoudsReliés 
			}
		}
		return nbarc; //retour du résultat 
	}

	@Override
	//retourne l'arc de poids le plus faible 
	public Edge  getLightest() {
		// TODO Auto-generated method stub
		int min=Integer.MAX_VALUE; //on initialise l'arc de poids de plus faible a l'arc dont le poids est dans la première case 
	Edge faiblepoids=null;
		for(int i=0;i<edges.length;i++) {
			for (int j=i+1;j<edges[0].length;j++) {
				if( edges[i][j]<min && edges[i][j]!=0) {
					min =edges[i][j];	
		faiblepoids=new Edge(nodes.get(i),nodes.get(j),min);	
				}
			}
			
		}
	return faiblepoids;
	}
	
	@Override
	public int getWeight(Character noeud1, Character noeud2) {
		int i=nodes.indexOf(noeud1);
		int j=nodes.indexOf(noeud2);
		return edges[i][j];
	}
	@Override
	public int numEdge() {
		// TODO Auto-generated method stub
		int total=0; // nombre total d'arc dans le graphe 
		// Pour faire cela on va parcourir tout le tableau à double entré et incrémenté 
		//total à chaque fois que le poids contenu dans la case est non nulle
		for(int i=0;i<nodes.size();i++) {
			for (int j=0;j< nodes.size();j++) {
				if(edges[i][j]!=0) {
					total++;
				}
			}
		}
		return total/2;// retourne le nombre d'arc total sur 2 étant donné que total prend en compte les arcs dans les deux sens
	}
	@Override
//création d'un  nouveau graphe vide 
	public void graph() {
//cela revient à un constructeur 
		nodes=new ArrayList<Character>();
		edges= new int[0][0];
	}
	@Override
	//ajouter un arc entre deux noeuds du graphe en précisant le poids. Si cet arc est déjà présent on fais une mis à jour 
	public void addEdge(Character noeud1, Character noeud2, int poids) {
	//on veut pouvoir connaitre l'indice des noeuds en paramètre dans la liste de noeuds 
// on utilise donc les variables i et j pour les contenir 
		int i=nodes.indexOf(noeud1); //indice du noeud 1 
		int j=nodes.indexOf(noeud2);// indice du noeud 2 
		// on met a jour la matrice de relation entre les noeuds 
		edges[i][j]=poids; // pour l'arc ij 
		edges[j][i]=poids; //et l'arc ji 
		
	}
	@Override
	public void addNode(Character noeud) {
		// TODO Auto-generated method stub
	// on ajoute un nouveau noeuds que s'il n'était pas encore présent dans le graphe 
		if(!nodes.contains(noeud)) {
			nodes.add(noeud);// on ajoute le nouveau noeud en paramètre
			//suite à l'ajout, la matrice de relation change de sorte que le nouveau noeuds n'est relié à aucun autre 
	//on a donc une nouvelle matrice de relation 
			int nouveledge[][]=new int [nodes.size()][nodes.size()];// de taille la nouvelle taille du noeuds 
//on remet l'ancienne matrice dans la nouvelle mais en prenant soin qu'il n'est pas de relation entre le nouveau noeuds et l'ancien 
			for (int i=0;i< nodes.size()-1;i++) {
				for (int j=0;j<nodes.size()-1;j++) {
					nouveledge[i][j]=edges[i][j];
				}
			}
			edges=nouveledge; //on réattribue à la matrice de relation la nouvelle matrice pour qu'on en ait plus qu'un 
			
		}
		
	}
	@Override
	public void delNode(Character noeud) {
	//en supprimant un noeud, on change la taille de la matrice de relation 
		nodes.remove(nodes.indexOf(noeud));// on supprime le noeud en paramètre 
//ensuite on supprime tous les arcs en relation avec elle également 
//(modification de la taille de la matrice => soustraction d'une ligne et d'une colonne)		
		int nouveledge[][]=new int [nodes.size()][nodes.size()];
for (int i=0;i< nodes.size()-1;i++) {
			for (int j=0;j<nodes.size()-1;j++) {
//Comme on a supprimé un noeuds,les noeuds suivants le noeuds supprimé sont décalé vers la gauche 
//donc si on veut y accéder on ne pourra pas vu que la taille de la liste à diminuer de 1
//il faut donc trouver les indices des anciennes positions des noeuds dans la matrice de base avant de les mettre dans la nouvelle matrice 
	int ancien_i=i; // l'indixe précédent demeure la même 		
	if(i>nodes.indexOf(noeud)){// mais si le noeud supprimer était placé avant le noeuds a l'indice 1 alors 
		ancien_i=ancien_i+1; //on incrémente son indice de 1 pour que edge puisse le retrouver 
	}
	int ancien_j=j; // l'indixe précédent demeure la même 		
	if(j>nodes.indexOf(noeud)){// mais si le noeud supprimer était placé avant le noeuds a l'indice 1 alors 
		ancien_j=ancien_j+1; //on incrémente son indice de 1 pour que edge puisse le retrouver 
	}
				nouveledge[i][j]=edges[ancien_i][ancien_j];
			}
		}
		edges=nouveledge; //on réattribue à la matrice de relation la nouvelle matrice pour qu'on en ait plus qu'un 
		
	}
	@Override
	public void delEdge(Character noeud1, Character noeud2) {
//on veut supprimer l'arc reliant les noeuds en paramètre 
// On va récuperer leur indice respectives 
	int i=nodes.indexOf(noeud1);
	int j=nodes.indexOf(noeud2);
// Ensuite on attribue au poids de l'arc entre ces deux noeuds la valeur de 0 
	edges[i][j]=0;
	edges[j][i]=0; // on le fais dans les deux sens 
		
	}

	//fonction qui retourne une liste des neouds voisins aux noeuds en paramètre 
		public ArrayList<Character> getVoisins(Character noeud) {
			ArrayList<Character> noeudRelié=new ArrayList<Character>();//une liste des noeuds reliés a ce noeud 
		// On se place dans une boucle pour parcourir toutes les options de liaison du noeud 
		// a un autre noeud du graphe 
			for(int i=0;i<nodes.size();i++) {
			// on vérifie si le noeud en paramètre est relié au noeud à l'indice i (parcours de toute la liste de noeuds) 
				if(edges[i][nodes.indexOf(noeud)]!=0) {
			noeudRelié.add(nodes.get(i));// s'il y a un arc entre ce noeud et un autre on met cet autre noeud dans la liste des neoudsReliés 
				}
			}
			return noeudRelié; //retour du résultat 
		}
	//fonction qui permet de vérifier s'il existe un chemin entre deux noeud 
//Pour cela on fera implementera l'algo de parcours en largeur 
// On vérifira si les neoud en paramètre sont connectés en utilisant la liste des noeuds des voisins du premier
// qu'on parcoura 
//Cette méthode est récursive vu qu'on l'utilisera elle même dans la méthode 
		public boolean CheminExiste(Character noeud1, Character noeud2) {
		    boolean[] voisinsVérifié = new boolean[nodes.size()]; //tableau de booléens qui dis si un voisin à été parcourus ou non 
		//il a la taille de node car un noeud peut être relié à tous les autres noeud
		    return algoDFS(noeud1, noeud2, voisinsVérifié);// l'appel à la fonction récursive qui dis si deux sont relié 
		}
	/*Cette fonction étant récursive vérifie dans le tous premier cas si le noeud est relié a lui même 
	 * Si oui on va mettre a jour le tableau des voisins en paramètre */
		public boolean algoDFS(Character n1, Character n2, boolean[] visited) {
		    visited[nodes.indexOf(n1)] = true;
		    if (n1.equals(n2)) {
		        return true;
		    }
	//On a déja vérifié si le noeud était connecté à lui même après on vérifie si le premier noeud 
	 //est connecté à son premier voisin et que se voisin n'a pas encore été visité 
	//Le but de cela est d'éviter les appels récursives 
	//On utilise cette méthode de boucle pour ne pas se préoccuper de nombre de voisin	    
		    for (Character i : getVoisins(n1)) {
		        if (areConnected(n1, i) && !visited[nodes.indexOf(i)]) {
		            if (algoDFS(i, n2, visited)) {
		                return true;
		            }
		        }
		    }
		    return false;
		}
//fonction d'affichage
	public void affichage() {
		System.out.println("Les noeuds:");
		for(int i=0;i<nodes.size();i++) {
			System.out.print(nodes.get(i)+"  ");
		}
		System.out.println("");
	for(int i=0;i<nodes.size();i++) {
		for(int j=0;j<nodes.size();j++) {
			System.out.print(edges[i][j]+ " ");
		}
		System.out.println("");
	}
		
	}
}
