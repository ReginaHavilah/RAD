/**
 * 
 */
/**
 * @author badarou
 *
 */
module projet_JAVA {
	requires java.desktop;
}