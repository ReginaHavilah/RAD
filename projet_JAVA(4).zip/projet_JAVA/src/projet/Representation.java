package projet;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;
import java.util.List;

import javax.swing.*;

import projet.Jeu.Niveau;

public class Representation {
	private JFrame frame;//création d'une instance de fenètre dans lequel tous les éléments du jeu vont se coordonné
	Scanner sc=new Scanner(System.in);//pour nous permettre de donner des noms aux joueurs 
	String joueur1;String joueur2;
	/*
	System.out.println("Nom du premier joueur:");
	joueur1=sc.next();
	System.out.println("Nom du second joueur");
	joueur2=sc.next();
	*///on peut le faire dans une boucle pour prendre en compte le nombre de joueur 
	Joueur gamersOne=new Joueur(joueur1);//le premier joueur 
	Joueur gamersTwo=new Joueur(joueur2);//le deuxième joueur
	List<Joueur> joueurs=new ArrayList<>(Arrays.asList(gamersOne,gamersTwo)); //la liste des joueurs
    Table_jeu gameboard=new Table_jeu();//la table du jeu 
  private Jeu game= new Jeu(joueurs,gameboard,Niveau.Confirme);//on crée une instance de jeu
    
	public Representation() {
	  frame=new JFrame("Color Addict");//on crée une fenètre Collor addict
	//on ajoute un bouton dans la fenetre pour crée une instance du jeu   
	  JButton yesPlay= new JButton("Play at Color Addict"); 
	  yesPlay.addActionListener(e->{	  
	 System.out.println("Création d'un jeu de"+game.gamers.size());//on stipule à l'utilisateur que le jeu à belle et bien été créé
	 }); 
	frame.getContentPane().add(yesPlay);//on ajoute le bouton a la fenetre 

	//Maintenant que le jeu à été crée on va commencer par jouer mais avant il faut mélanger les cartes et les distribuer
	
	JButton distribute=new JButton("Shuffle and deal the cards");
	distribute.addActionListener(e->{
		game.melange();//le mélange des cartes 
		game.distribution();//la distribution des cartes aux joueurs
	});
	frame.getContentPane().add(distribute);//on ajoute ce bouton à la fenètre pas besoin
	frame.setSize(600, 600);//on définit la taille de la fenetre
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   frame.pack();//pour ajuster la taille aux différents composants
    frame.setVisible(true);//on décide de la rendre visible
	
//Ajout de la façon de visualiser la main des joueurs (parcours des joueurs et affichage de Karty)
    //ainsi que la première carte posé	(table.Karte.get(0)
    
	}

	
}
