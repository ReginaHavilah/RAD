package projet;
import java.util.List;
import java.util.Scanner;
import java.util.ListIterator;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.Iterator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import projet.Carte.Couleur;
public class Jeu {
	public enum Niveau {// les differents niveau pour jouer
		Debutants,
		Inities,
		Confirme,

	} 
	private  Niveau level=null; // le niveau de jeu choisit 
	private  List <Carte> cards; //la liste des cartes dans le jeu 
	public List<Joueur> gamers; //la liste des joueurs dans le jeu 
	public Table_jeu table; //la table du jeu 
	private Donneur donneur; //le donneur dans le jeu qui fais partie des joueurs 
	private Couleur couleuractuelle;


	public List<Carte> generer(){//la mÃ©thode qui gÃ©nÃ¨re la pile de carte nÃ©cessaire pour le jeu
		//dans notre jeu on a cinq couleur donc la pile de carte simple disponible est au nombre de 5! 

		List<Carte> res=new ArrayList<Carte>();//la liste de carte Ã  retournÃ© 
		Couleur[] coo;
		if (level == Niveau.Confirme || level == Niveau.Inities) {
		    System.out.println("Niveau Confirme ou Initie");
		    coo = new Couleur[]{Couleur.BLEUE, Couleur.JAUNE, Couleur.NOIRE, Couleur.ROUGE, Couleur.VERTE};
		} else {
		    System.out.println("Niveau Debutants");
		    coo = new Couleur[]{Couleur.BLEUE, Couleur.JAUNE, Couleur.ROUGE, Couleur.VERTE};
		}
		// la liste des couleurs possible sans le multicolore

		//on fera une boucle dans une boucle pour avoir toute les combinaisons possible de mot et de couleur 
		for (Couleur c: coo ) {
			for (Couleur e: coo) {
				Carte creation=new Carte (c,e); //on crÃ©e une nouvelle carte avec une combinaison possible de couleur et de mot en couleur 
				res.add(creation); //on ajoute cette carte dans la liste de carte 
			}
		}
		//ensuite on ajoutera quatre carte joker dans le jeu 
		
res.add(new Joker());	
res.add(new Joker());
res.add(new Joker());
res.add(new Joker());
		return res;
	}

	//le choix du donneur dans le jeu 
	public static Donneur choixDonneur(List< Joueur> liste) {
		Donneur res=new Donneur(null);
		for(Joueur e: liste) {
			if(e instanceof Donneur) {
				res=(Donneur) e;//on attribue a l'Ã©lÃ©ment donneur le donneur choisit dans la liste des joueurs 
			}
		}

		return  res; //on retourne le joueur Ã  cette position
	}
	//le constructeur pour la crÃ©ation du jeu : pour un jeu il faut des joueurs et un lot de carte 	
	public Jeu(List<Joueur> gamers,Table_jeu table, Niveau level) {
		this.gamers=gamers;
		this.level=level;
		this.cards=generer();//on gÃ©nÃ¨re des cartes simple et on y ajoute 4 jokers
		this.donneur= choixDonneur(gamers);//le donneur est chosit alÃ©atoirement dans la liste des joueurs
		this.table=table;
		
		//pour le level du jeu on laissera le choix Ã  l'utilisateur 
	}
	//la mÃ©thode qui permet de distribuer des cartes et d'attribuer les pioches aux joueurs 
	public void distribution () {
		 //le nombre de carte au dÃ©part moins la carte Ã  mettre au centre 
		//crÃ©ation d'une instance random 
		Random random=new Random();
		//une boucle qui parcours la liste des joueurs dans le jeu pour leur distribuer trois carte Ã  chacun de faÃ§on alÃ©atoire
		for (Joueur j:gamers) {//pour chaque joueur 
			for (int i=0;i<3; i++) {//on lui donne trois carte 
				int num= random.nextInt(cards.size());// pris alÃ©atoirement dans la liste des cartes disponibles 
				j.Karty.add(cards.get(num));//ces cartes alÃ©atoires sont ainsi ajoutÃ© Ã  la main du joueur
				cards.remove(num);//on retire la carte prÃ©cedemment distribuÃ© pour ne pas le distribuer deux fois 
				//on met Ã  jour la taille de la liste
			}
		}
		//aprÃ¨s avoir distribuer les cartes aux joueurs il faut leur donner Ã  chacun une pioche 
		//les pioches doivent Ãªtre Ã¨gales pour les joueurs
		int sizepioche=cards.size()/gamers.size();//la taille des pioches est obtenue en divisant le nombre de carte restant de faÃ§on Ã©gale entre les joueurs
		for (Joueur j:gamers) {
			for (int i=0;i<sizepioche; i++) {
				int num= random.nextInt(cards.size());
				j.pioche.add(cards.get(num));
				cards.remove(num);
				
			}
		}
		//si aprÃ¨s le partage, il y a des cartes restantes on les supprime 
		while (!cards.isEmpty()) {
			cards.remove(0);
		}
	}

	//la mÃ©thode qui permet de mÃ©langer l'ensemble des cartes du jeu afin d'avoir un jeu plus juste 
	public void melange() {
		//pour le mÃ©lange des cartes de la liste on le fera de faÃ§on alÃ©atoire avec la mÃ©thode shuffles de la classe collection 
		//on appellera donc la mÃ©thode shuffles de la classe collection sur la liste de carte disponible 
		Collections.shuffle(cards);
	}
public void initialisegame() {//initialisation du jeu pour un level confirmÃ© ou initiÃ©s
	melange();
	distribution();
	donneur.PoseOnTable(table.Karte);
	//pour commencer le jeu on melange les cartes, on les distribue entre les joueurs et le donneur pose la premiÃ¨re carte sur la table 
};


//MÃ©thode simplifiÃ©e pour vÃ©rifier si une carte peut Ãªtre dÃ©posÃ©e
private boolean canDepositCard(Carte carte) {
    // Si la couleur actuelle est définie (après avoir joué un Joker), vérifiez si la carte correspond
    if (couleuractuelle != null) {
        return carte.color.equals(couleuractuelle) || 
               carte.mot.equals(couleuractuelle) || 
               carte instanceof Joker;
    } else {
        Carte lastCard = table.Karte.get(table.Karte.size() - 1);
        return carte.color.equals(lastCard.color) ||
               carte.mot.equals(lastCard.mot) ||
               carte.mot.equals(lastCard.color) ||
               carte.color.equals(lastCard.mot) ||
               carte instanceof Joker;
    }
}


// Methode pour demander la prochaine couleur apres q'un joueur est depose un Joker
private Couleur askNextColor(Joueur joueur) {
    Scanner sc = new Scanner(System.in);
    System.out.println(joueur.nom + ", vous avez jouer un Joker. Choisissez la prochaine couleur :");
    String chosenColor = sc.nextLine().toUpperCase();
    // Convertir la chaine de caracteres en enumeration Couleur
    try {
        return Couleur.valueOf(chosenColor);
    } catch (IllegalArgumentException e) {
        System.out.println("Couleur non valide. Veuillez reessayer.");
        return askNextColor(joueur); // pour demander a  nouveau
    }
}

//methode qui permet a un joueur de jouer une carte si il peut, cela retourne la carte qu'il veut deposer 
//prend un joueur en parametre et consiste a parcourir les carte du joueur 
public Carte DeposerCarte(Joueur j) {
	Carte res=null;
	for(Carte c: j.Karty) {
		if(canDepositCard(c)) {
			res=c;
			break;//si on trouve une carte qui marche on sort de la boucle 
		}
	}
	 return res;	
}

//une methode qui permet au joueur j de joueur la carte c dans les regles du jeu 
public void PlayCard(Joueur j, Carte c) {
		table.Karte.add(c);
        j.Karty.remove(c);
        System.out.println(j.nom + " a depose la carte " + c);     
        if (c instanceof Joker) {
            couleuractuelle = askNextColor(j); // Demander la couleur après avoir joué un Joker
        } else {
            // Si la carte n'est pas un Joker, on remet couleurActuelle à null
            couleuractuelle = null;
        }
}

//une methode qui verifie si le jeu est bloque 
public boolean bloque(List<Joueur> joueurs) {
    for (Joueur j : joueurs) {
        for (Carte c : j.Karty) {
            if (canDepositCard(c)) {
                // Un joueur peut déposer au moins une carte, le jeu n'est pas bloqué
                return false;
            }
        }
    }
    // Aucun joueur ne peut déposer, le jeu est bloqué
    return true;
}

//une methode qui chosiis une couleur au hasard 
//Fonction pour obtenir une couleur au hasard parmi les couleurs disponibles
private Couleur getRandomColor() {
	Couleur[] coo= new Couleur []{Couleur.BLEUE,Couleur.JAUNE,Couleur.ROUGE,Couleur.VERTE};
 List<Couleur> couleursDisponibles = Arrays.asList(coo); // Assurez-vous d'ajuster selon votre modèle de données
 Random random = new Random();
 return couleursDisponibles.get(random.nextInt(couleursDisponibles.size()));
}


public void JouerTour(Joueur j) {
	if (j.Karty.size() == 3) {
		Carte carte=DeposerCarte(j);
		if(carte!=null) {
			PlayCard(j,carte);//le joueur joue la carte
 
			if(!j.pioche.isEmpty()) {
				j.piocher();
			}
			System.out.println(j.nom+" a maintenant "+j.Karty.size()+ " cartes en main et "+j.pioche.size() +" dans sa pioche");  
		}else {
			if(!j.pioche.isEmpty()) {
				System.out.println(j.nom+" n'a pas la carte correspondante et pioche une carte");
				j.piocher();
			}else {
				System.out.println(j.nom+ " n'a pas la carte. +Pioche vide donc on passe son tour.");
			}
		}
	} else {
		Carte carte=DeposerCarte(j);
		if(carte!=null) {
			PlayCard(j,carte);//le joueur joue la carte 
		}else {
			if(!j.pioche.isEmpty()) {
				System.out.println(j.nom+" n'a pas la carte correspondante et pioche une carte");
				j.piocher();
			}else {
				System.out.println(j.nom+ " n'a pas la carte. Pioche vide donc on passe son tour.");
			}
		}

	}
}


public Joueur Game(List<Joueur> gagnants, List<Joueur> listeJoueur) {
	List<Joueur> joueurList = new ArrayList<>(listeJoueur);
	boolean firstIteration = true;

	while (joueurList.size()> 1) {
		Iterator<Joueur> iterator = joueurList.iterator();
		while (iterator.hasNext()) {
			Joueur j = iterator.next();
			System.out.println(j.nom+" commence avec"+j.Karty.size()+" cartes en main et"+j.pioche.size() +" dans sa pioche");
			// Verifier si le joueur n'est pas le donneur lors de la premiÃ¨re itÃ©ration
			if (!firstIteration || !(j instanceof Donneur)) {
				
				//on verifie si le jeu est bloqué avant de poursuivre 
				if(bloque(joueurList)) {
					couleuractuelle= getRandomColor(); // si le jeu est bloque alors on choisit une couleur au hasard 
				}
			//sinon on poursuis 
				// Verifier si le joueur en question est un gagnant 
				if (j.Karty.isEmpty()) {
					System.out.println(j.nom +" sort du jeu");
					gagnants.add(j);
					iterator.remove();
					continue;//passe au joueur suivant
				}
				
     //sinon alors c'est un joueur qui peut joueur 
				//si il a exactement trois carte en main
				JouerTour(j);
				 }
		}
		firstIteration = false;
    }
    return gagnants.isEmpty() ? null : gagnants.get(0);
}


//logique du jeu pour un confirme 
public Joueur GameConfirme(List<Joueur> gagnants, List<Joueur> listeJoueur) {
    List<Joueur> joueurList = new ArrayList<>(listeJoueur);

    while (joueurList.size() > 1) {
        joueurList.parallelStream().forEach(j -> {
            System.out.println(j.nom + " commence avec " + j.Karty.size() + " cartes en main et " + j.pioche.size() + " dans sa pioche");

            // Vérifier si le jeu est bloqué avant de poursuivre
            if (bloque(joueurList)) {
                couleuractuelle = getRandomColor(); // Si le jeu est bloqué, choisir une couleur au hasard
            }

            // Vérifier si le joueur en question est un gagnant
            if (j.Karty.isEmpty()) {
                System.out.println(j.nom + " sort du jeu");
                gagnants.add(j);
            } else {
                JouerTour(j);
            }
        });

        // Supprimer les joueurs sortis du jeu
        joueurList.removeIf(j -> j.Karty.isEmpty());
    }

    return gagnants.isEmpty() ? null : gagnants.get(0);
}

	//ensuite viens la mÃ©thode essentielle du jeu qui est jouÃ© 
	public String jouer() {

		
		List<Joueur> gagnants=new ArrayList<>();//la liste des gagnants en gardant l'ordre de sortie des joueurs 	
		// selon le niveau s'applique des rÃ¨gles
		Joueur gagnant=new Joueur("");//le joueur Ã  retourner Ã  la fin 
		switch (level) { 
		case Confirme:
			initialisegame();
			gagnant=GameConfirme(gagnants,gamers);
			System.out.println("No game");
			break;
		case Inities:
			initialisegame();//on initialise le jeu 
			//ensuite on suit la logique 
			gagnant=Game(gagnants,gamers);
				break;
		case Debutants:	
			initialisegame();//on initialise le jeu 
			//ensuite on suit la logique 
			gagnant=Game(gagnants,gamers);
			break;
		default: System.out.println("Niveau non pris en compte par le jeu");
		break;
		}
		return gagnant.nom;
	}
	
	
	public void affichage() {
		System.out.println("Le niveau du jeu choisit est: " +level);
		System.out.println("On a :"+gamers.size()+" joueurs");
		for(int i=0;i<gamers.size();i++) {
			System.out.println(gamers.get(i).toString());
		}
		System.out.println("On a "+cards.size()+ " cartes dans le jeu.");
		for (int i=0; i<cards.size();i++) {
			System.out.println(cards.get(i).toString());
		}
		System.out.println("Celui qui debutera le jeu est: "+donneur);
	}
	
}