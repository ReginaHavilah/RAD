package Projet;

import java.util.ArrayList;

public class Entreprise {
public ArrayList<String> villes; //liste de ville du réseau 
public GraphMatrix reseau_national;// graphe du réseau ferré global 
public GraphMatrix reseau_entreprise;// graphe du réseau que doit maintenir l'entreprise 

//constructeur de la classe
public Entreprise(){
	this.villes=new ArrayList<String>();
	this.reseau_national=new GraphMatrix();
	this.reseau_entreprise= new GraphMatrix();
	//this.reseau_entreprise=optimal(this.reseau_national);
}
//fonction de la classe 

public void add_city(String newcity,Character newNode ) {
	//ajoute une ville au réseau sans voie 
//en ajoutant une ville au réseau, il faut également ajouter un noeud au réseau national au même indice 
	if(!villes.contains(newcity)) {
		villes.add(newcity);
		reseau_national.addNode(newNode);
		reseau_entreprise.addNode(newNode);
	}
//ajouter également le neoud lui correspondant 
	
}
//Prend en paramètre les deu villes qu'il faut relier avec la voie et le cout d'exploitation de cette ligne
public void add_rail(String ville1,String ville2,int cout) {
	//ajoute une voie ferré entre deux villes 
	//On récupère l'indice ou se trouve les villes en paramètre dans la liste des vvilles du réseau 
	int i=villes.indexOf(ville1);
	int j=villes.indexOf(ville2);
//Les noeuds correspondant aux villes et les arcs aux voies alors 
	//ajouter une voie renvoi a ajjouter un arc dans le réseau 
//l'indice ou se trouve une ville dans la liste des villes est le même que l'indice ou se trouve le noeud qui le représente
	//trouvons les noeuds correspondant au villes dans la liste des noeuds du réseau 
char noeud1=reseau_national.nodes.get(i); //le noeud correspondant à la ville1
char noeud2=reseau_national.nodes.get(j);//le noeud correspondant à la ville2
	reseau_national.addEdge(noeud1, noeud2,cout);//ajout d'un arc entre ces deux noeuds
	//reseau_entreprise.addEdge(noeud1, noeud2,cout);
}
public void del_rail(String ville1,String ville2) {
	//supprime une voie ferré entre deux villes 
//même logique que pour ajouter une voies 
	int i=villes.indexOf(ville1);
	int j=villes.indexOf(ville2);
	char noeud1=reseau_national.nodes.get(i);
	char noeud2=reseau_national.nodes.get(j);	
	reseau_national.delEdge(noeud1, noeud2);
}

 public GraphMatrix optimal(GraphMatrix graphe) {
	 //met a jour reseau entreprise pour qu’il corresponde bien au réseau optimal pour l’entreprise,
	 //  etant donne l ́etat actuel du reseau global
	 //Algorithme de Kruskal 
	GraphMatrix arbreminimal=new GraphMatrix();// le graphe vide qui est l'arbre couvrant minimal en cours de construction 
	 int N=graphe.nodes.size(); //nombre de noeud dans le reseau qu'on veut optimiser
	 int taille_G2=arbreminimal.numEdge(); //nombre d'arc dans l'arbre qu'on essai d'obtenir 
	 int taille_G1=graphe.numEdge();// nommbre d'arc dans le réseau qu'on veut optimiser  
	 Edge faible; // 
while(taille_G2<N-1 && taille_G1>1) {//tant que le nombre de noeuds dans le reseau de l'entreprise est inférieur au nombre d'arc dans le reseau national
		//et que le nombre d'arc dans le reseau national n'est pas vide alors 
  faible=graphe.getLightest();//on récupère l'arc le plus faible du réseau qu'on veut optimiser
graphe.delEdge(faible.getSommet1(),faible.getSommet2());// on supprime cet arc du reseau national, donc sa taille doit diminuer d'un grade 
//si le reseau de l'entreprise ne contient pas l'un des noeuds de l'arc le plus faible du réseau national on l'ajoute 
if(!arbreminimal.nodes.contains(faible.getSommet1())) {
		arbreminimal.addNode(faible.getSommet1()); //ajout du noeud en cas de son absence
	}
if(!arbreminimal.nodes.contains(faible.getSommet2())) {
		arbreminimal.addNode(faible.getSommet2());
		
	}
//s'il n'exiiste pas de chemin du noeud 1 au noeud 2 on ajoute un arc entre eux 
// pour ce faire on utilisera  notre méthode cheminExiste 
if(!arbreminimal.CheminExiste(faible.getSommet1(), faible.getSommet2())) {	 
		arbreminimal.addEdge(faible.getSommet1(),faible.getSommet2(),faible.getPoids());
	 }
//Ici on obtient le réseau que couvre l'entreprise 	 
 taille_G2=arbreminimal.numEdge();
 taille_G1=graphe.numEdge();
 }

return arbreminimal;
}

 
 public GraphMatrix getReseau_entreprise() {
	return reseau_entreprise;
}
//méthode pour pouvoir modifier le reseau de l'entreprise
public void setReseau_entreprise(GraphMatrix reseau) {
	this.reseau_entreprise = optimal(reseau);
}

public void afficher() {
	 System.out.println("La liste des villes dans le réseau global:");
	 for(int i=0;i<villes.size();i++) {
		 System.out.println(villes.get(i)+"   ");
	 }
	 System.out.println("Les noeuds et arcs du reseau global se présente comme suit:");
	 reseau_national.affichage();
	// reseau_entreprise.affichage();
	// System.out.println("Le reseau optimal pour l'entreprise se présente comme suit:");
	 optimal(reseau_national).affichage();
 }
 
 
/*
 *Quand on supprime ou ajoute une voie, il faut peut ê†re le fait dans les deux réseaux et le reseau entreprise doit forcement thrs prendre en compte la fonction optimal
 public void afficherminimal() {
	 System.out.println("Arbre couvrant minimal:");
	 reseau_entreprise.affichage();
 }la fonction optimal est bien sur a revoir **/
}
