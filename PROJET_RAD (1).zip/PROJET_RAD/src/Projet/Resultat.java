package Projet;

public class Resultat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Entreprise entreprise=new Entreprise();
		entreprise.setReseau_entreprise(entreprise.reseau_national);
	//ajouter des villes et des rails dans le reseau de l'entreprise 
		entreprise.add_city("Paris",'P');
		entreprise.add_city("Nancy", 'N');
		entreprise.add_city("Strasbourg",'S');
		entreprise.add_city("Lille", 'L');
		entreprise.add_city("Rennes", 'R');
	//rail 
		entreprise.add_rail("Paris", "Nancy", 150);
      entreprise.add_rail("Paris", "Strasbourg", 175);
		entreprise.add_rail("Nancy", "Strasbourg", 60);
		entreprise.add_rail("Lille", "Strasbourg", 40);
		entreprise.add_rail("Nancy", "Lille", 260);
		entreprise.add_rail("Paris", "Lille", 30);
		entreprise.add_rail("Nancy", "Rennes", 50);
//Affichage des villes voisines à chaque ville
		System.out.println("Liste des ville voisins a Paris:"+entreprise.reseau_national.getVoisins('P'));
		System.out.println("Liste des ville voisins a Nancy:"+entreprise.reseau_national.getVoisins('N'));
		System.out.println("Liste des ville voisins a Lille:"+entreprise.reseau_national.getVoisins('L'));
		System.out.println("Liste des ville voisins a Strasbourg:"+entreprise.reseau_national.getVoisins('S'));
		System.out.println("Liste des ville voisins a Rennes:"+entreprise.reseau_national.getVoisins('R'));
//affichage du nombre de noeud et du nombre d'arc 
	System.out.println("Nombre de ville:"+entreprise.reseau_national.nodes.size());
	System.out.println("Nombre d'arc:"+entreprise.reseau_national.numEdge());
//Affichage du réseau national et du réseau optimal 
	entreprise.afficher();
		

}
}
